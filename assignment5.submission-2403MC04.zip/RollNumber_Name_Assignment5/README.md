# Operating Systems Lab — Assignment 5: Process Synchronization using xv6

This submission targets the standard **MIT xv6-riscv** source tree.

## What is included
- `kernel/` — kernel-side changes for a shared memory page and lightweight semaphores.
- `user/` — `peterson.c`, `prodcons.c`, `readwrite.c`, and `dining.c`.
- `Makefile.additions` — exact Makefile edits to add the four user programs.
- `README.md` — design, build, run, and screenshot instructions.
- `output_logs/` — place the terminal transcripts/screenshots here after running xv6.

The assignment asks for the folder to be named `RollNumber_Name_Assignment4`; replace `RollNumber_Name` with your actual details before submission.

## Design

### Shared memory
A new `shm_get()` system call allocates one physical page and maps it into the calling process at `SHMBASE`. The process records the physical page in `struct proc`. `fork()` maps the same physical page into the child instead of copying it. The shared page is therefore genuinely shared by parent and child. The shared mapping is removed without freeing the physical page until the last process using it exits.

### Semaphores
The kernel contains a small fixed table of counting semaphores. `sem_create(initial)` allocates an entry. `sem_wait(id)` sleeps using xv6's `sleep()/wakeup()` mechanism while the count is zero, and `sem_post(id)` increments the count and wakes a waiter. The semaphore table is protected by a kernel spinlock; the semaphore's own lock protects its count.

### Q1 — Peterson
Only `flag[2]` and `turn` implement mutual exclusion. No semaphore, spinlock, or xv6 lock is used around the critical section. The shared counter is incremented inside Peterson's critical section.

### Q2 — Producer/Consumer
Uses a circular buffer of configurable size (default 5), with `empty` and `full` counting semaphores and a `mutex` binary semaphore. The producer generates 1–20; the consumer removes them in order. Explicit messages show when producer/consumer block.

### Q3 — Readers/Writers
Uses a shared page for `read_count`, `shared_data`, and instrumentation counters. A mutex protects `read_count`; `rw` gives writers exclusive access. Readers acquire `rw` only for the first reader and release it only for the last reader, permitting concurrent readers. A bounded admission scheme is included so writers are not indefinitely starved: readers take a `turnstile` semaphore before entering the reader protocol, while writers pass through the same turnstile before taking `rw`.

### Q4 — Dining Philosophers
Uses five semaphore-protected forks. Deadlock is avoided by **resource ordering**: each philosopher always acquires the lower-numbered fork first and the higher-numbered fork second. This removes the circular-wait condition required for deadlock.

## Build

1. Start from a clean xv6-riscv source tree.
2. Copy the files in this submission into the corresponding `kernel/` and `user/` directories.
3. Apply the Makefile additions shown in `Makefile.additions`.
4. Run:

```bash
make clean
make qemu
```

If your environment uses `qemu-system-riscv64` and the standard xv6 toolchain, this should build and launch xv6.

## Run commands and screenshots

Inside the xv6 shell, run each program separately:

```text
$ peterson
$ prodcons
$ prodcons 3
$ readwrite
$ dining
```

For the required screenshots, capture the complete output for each command. The most useful screenshots are:

1. `peterson` — output showing alternating CS entries and `Final counter = 20`.
2. `prodcons` — output showing `BUFFER FULL` / `BUFFER EMPTY` waits and all values 1–20 consumed in order.
3. `readwrite` — output with PID/state information showing reader overlap and exclusive writer sections, ending with the final shared value.
4. `dining` — output showing every philosopher complete all five cycles.

You can save terminal transcripts from the host with the emulator output, or simply take screenshots of the terminal. Put them in `output_logs/`.

## What to submit
According to the assignment sheet, submit:

- all modified/added `.c` and `.h` files;
- updated `Makefile`;
- this `README.md`;
- screenshots or `.txt` terminal transcripts for all four questions;
- compressed folder (`.zip` or `.tar.gz`).

The assignment sheet specifies the folder name `RollNumber_Name_Assignment4` and requires output logs for each question. fileciteturn0file0L120-L124
