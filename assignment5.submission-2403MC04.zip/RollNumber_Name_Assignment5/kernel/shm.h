#ifndef XV6_SHM_H
#define XV6_SHM_H

#include "types.h"

// One page is shared between a process and its forked child.
#define SHMBASE 0x40000000UL

#endif
