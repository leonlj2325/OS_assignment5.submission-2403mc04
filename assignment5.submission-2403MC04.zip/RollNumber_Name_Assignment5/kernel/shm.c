#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "riscv.h"
#include "shm.h"

static struct {
  struct spinlock lock;
  uint64 pa;
  int refs;
} shared_page;

void
shm_init(void)
{
  initlock(&shared_page.lock, "shm");
  shared_page.pa = 0;
  shared_page.refs = 0;
}

// Allocate the shared page for p and map it at a fixed user virtual address.
// A second call by the same process simply returns the existing mapping.
uint64
shm_get(void)
{
  struct proc *p = myproc();
  uint64 pa;

  if(p->shm_pa != 0)
    return SHMBASE;

  acquire(&shared_page.lock);
  if(shared_page.pa == 0){
    pa = (uint64)kalloc();
    if(pa == 0){
      release(&shared_page.lock);
      return 0;
    }
    memset((void*)pa, 0, PGSIZE);
    shared_page.pa = pa;
    shared_page.refs = 1;
  } else {
    pa = shared_page.pa;
    shared_page.refs++;
  }
  release(&shared_page.lock);

  if(mappages(p->pagetable, SHMBASE, PGSIZE, pa, PTE_R|PTE_W|PTE_U) < 0){
    acquire(&shared_page.lock);
    shared_page.refs--;
    if(shared_page.refs == 0){
      kfree((void*)shared_page.pa);
      shared_page.pa = 0;
    }
    release(&shared_page.lock);
    return 0;
  }
  p->shm_pa = pa;
  return SHMBASE;
}

// Map the parent's shared page into the newly-created child.
int
shm_fork(struct proc *parent, struct proc *child)
{
  if(parent->shm_pa == 0)
    return 0;

  if(mappages(child->pagetable, SHMBASE, PGSIZE, parent->shm_pa,
              PTE_R|PTE_W|PTE_U) < 0)
    return -1;

  acquire(&shared_page.lock);
  shared_page.refs++;
  release(&shared_page.lock);
  child->shm_pa = parent->shm_pa;
  return 0;
}

void
shm_release(struct proc *p)
{
  if(p->shm_pa == 0)
    return;

  uvmunmap(p->pagetable, SHMBASE, 1, 0);
  p->shm_pa = 0;

  acquire(&shared_page.lock);
  shared_page.refs--;
  if(shared_page.refs == 0){
    kfree((void*)shared_page.pa);
    shared_page.pa = 0;
  }
  release(&shared_page.lock);
}
