#ifndef XV6_SEM_H
#define XV6_SEM_H

#define NSEM 32

struct semaphore {
  struct spinlock lock;
  int used;
  int value;
};

void sem_init(void);
int sem_create(int value);
int sem_wait(int id);
int sem_post(int id);

#endif
