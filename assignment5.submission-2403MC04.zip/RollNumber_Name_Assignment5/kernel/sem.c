#include "types.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "sem.h"

static struct {
  struct spinlock lock;
  struct semaphore s[NSEM];
} semtab;

void
sem_init(void)
{
  initlock(&semtab.lock, "semtab");
  for(int i = 0; i < NSEM; i++){
    initlock(&semtab.s[i].lock, "sem");
    semtab.s[i].used = 0;
    semtab.s[i].value = 0;
  }
}

int
sem_create(int value)
{
  if(value < 0)
    return -1;
  acquire(&semtab.lock);
  for(int i = 0; i < NSEM; i++){
    if(!semtab.s[i].used){
      semtab.s[i].used = 1;
      semtab.s[i].value = value;
      release(&semtab.lock);
      return i;
    }
  }
  release(&semtab.lock);
  return -1;
}

int
sem_wait(int id)
{
  if(id < 0 || id >= NSEM || !semtab.s[id].used)
    return -1;
  struct semaphore *s = &semtab.s[id];
  acquire(&s->lock);
  while(s->value == 0)
    sleep(s, &s->lock);
  s->value--;
  release(&s->lock);
  return 0;
}

int
sem_post(int id)
{
  if(id < 0 || id >= NSEM || !semtab.s[id].used)
    return -1;
  struct semaphore *s = &semtab.s[id];
  acquire(&s->lock);
  s->value++;
  wakeup(s);
  release(&s->lock);
  return 0;
}
