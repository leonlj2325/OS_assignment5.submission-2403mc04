#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define READERS 3
#define WRITERS 2
#define READ_ROUNDS 5
#define WRITE_ROUNDS 5

struct rw_state {
  int shared_data;
  int read_count;
  int active_readers;
  int active_writers;
};

static void delay(void)
{
  for(volatile int i = 0; i < 80000; i++) ;
}

int
main(void)
{
  struct rw_state *s = (struct rw_state*)shm_get();
  if(s == 0){ printf("readwrite: shm_get failed\n"); exit(1); }
  s->shared_data = 0;
  s->read_count = 0;
  s->active_readers = 0;
  s->active_writers = 0;

  // mutex protects read_count; rw protects shared_data; queue prevents
  // readers arriving behind a writer from overtaking it indefinitely.
  int mutex = sem_create(1);
  int rw = sem_create(1);
  int queue = sem_create(1);
  if(mutex < 0 || rw < 0 || queue < 0){
    printf("readwrite: semaphore creation failed\n");
    exit(1);
  }

  int children = 0;
  for(int r = 0; r < READERS; r++){
    int pid = fork();
    if(pid < 0) exit(1);
    if(pid == 0){
      for(int k = 0; k < READ_ROUNDS; k++){
        sem_wait(queue);
        sem_wait(mutex);
        s->read_count++;
        if(s->read_count == 1)
          sem_wait(rw);
        s->active_readers++;
        sem_post(mutex);
        sem_post(queue);

        printf("Reader PID %d: READING shared_data=%d (active readers=%d)\n",
               getpid(), s->shared_data, s->active_readers);
        delay();

        sem_wait(mutex);
        s->active_readers--;
        s->read_count--;
        if(s->read_count == 0)
          sem_post(rw);
        sem_post(mutex);
        delay();
      }
      exit(0);
    }
    children++;
  }

  for(int w = 0; w < WRITERS; w++){
    int pid = fork();
    if(pid < 0) exit(1);
    if(pid == 0){
      for(int k = 0; k < WRITE_ROUNDS; k++){
        sem_wait(queue);
        sem_wait(rw);
        sem_post(queue);

        if(s->active_readers != 0 || s->active_writers != 0)
          printf("ERROR: writer overlap detected\n");
        s->active_writers = 1;
        s->shared_data++;
        printf("Writer PID %d: WRITING shared_data=%d (exclusive)\n",
               getpid(), s->shared_data);
        delay();
        s->active_writers = 0;
        sem_post(rw);
        delay();
      }
      exit(0);
    }
    children++;
  }

  for(int i = 0; i < children; i++)
    wait(0);
  printf("Final shared_data = %d (expected %d)\n", s->shared_data,
         WRITERS * WRITE_ROUNDS);
  exit(0);
}
