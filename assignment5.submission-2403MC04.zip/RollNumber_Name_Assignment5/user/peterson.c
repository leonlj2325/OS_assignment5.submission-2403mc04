#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define ITERATIONS 10

struct shared_peterson {
  volatile int flag[2];
  volatile int turn;
  volatile int shared_counter;
  volatile int in_cs;
};

static void
delay(void)
{
  for(volatile int i = 0; i < 200000; i++)
    ;
}

static void
enter_cs(struct shared_peterson *s, int id)
{
  int other = 1 - id;
  s->flag[id] = 1;
  s->turn = other;
  __sync_synchronize();
  while(s->flag[other] && s->turn == other)
    ;
}

static void
leave_cs(struct shared_peterson *s, int id)
{
  __sync_synchronize();
  s->flag[id] = 0;
}

int
main(void)
{
  struct shared_peterson *s = (struct shared_peterson*)shm_get();
  if(s == 0){
    printf("peterson: shm_get failed\n");
    exit(1);
  }

  s->flag[0] = 0;
  s->flag[1] = 0;
  s->turn = 0;
  s->shared_counter = 0;
  s->in_cs = 0;
  __sync_synchronize();

  int pid = fork();
  if(pid < 0){
    printf("peterson: fork failed\n");
    exit(1);
  }

  int id = (pid == 0) ? 1 : 0;
  for(int i = 0; i < ITERATIONS; i++){
    enter_cs(s, id);

    if(s->in_cs != 0)
      printf("ERROR: mutual exclusion violated by process %d\n", id);
    s->in_cs = 1;
    s->shared_counter++;
    printf("Process %d in CS, counter = %d\n", id, s->shared_counter);
    delay();
    s->in_cs = 0;
    printf("Process %d leaving CS\n", id);

    leave_cs(s, id);
    delay();
  }

  if(pid != 0){
    wait(0);
    printf("Final counter = %d (expected %d)\n",
           s->shared_counter, 2 * ITERATIONS);
  }
  exit(0);
}
