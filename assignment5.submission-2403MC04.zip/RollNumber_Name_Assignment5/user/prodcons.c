#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define DEFAULT_SIZE 5
#define ITEMS 20

struct buffer_state {
  int buf[20];
  int size;
  int in;
  int out;
};

static void
busy_delay(void)
{
  for(volatile int i = 0; i < 120000; i++)
    ;
}

int
main(int argc, char **argv)
{
  int size = DEFAULT_SIZE;
  if(argc > 1){
    size = atoi(argv[1]);
    if(size < 1 || size > 20){
      printf("Usage: prodcons [buffer_size 1..20]\n");
      exit(1);
    }
  }

  struct buffer_state *s = (struct buffer_state*)shm_get();
  if(s == 0){
    printf("prodcons: shm_get failed\n");
    exit(1);
  }
  s->size = size;
  s->in = 0;
  s->out = 0;

  int empty = sem_create(size);
  int full = sem_create(0);
  int mutex = sem_create(1);
  if(empty < 0 || full < 0 || mutex < 0){
    printf("prodcons: semaphore creation failed\n");
    exit(1);
  }

  int pid = fork();
  if(pid < 0){
    printf("prodcons: fork failed\n");
    exit(1);
  }

  if(pid == 0){
    // Consumer: waits on full before touching the buffer.
    for(int n = 0; n < ITEMS; n++){
      if(sem_wait(full) < 0) exit(1);
      if(sem_wait(mutex) < 0) exit(1);
      int item = s->buf[s->out];
      s->out = (s->out + 1) % s->size;
      sem_post(mutex);
      sem_post(empty);
      printf("Consumer PID %d: consumed %d\n", getpid(), item);
      busy_delay();
    }
    exit(0);
  }

  // Producer: waits on empty before inserting into the circular buffer.
  for(int item = 1; item <= ITEMS; item++){
    if(sem_wait(empty) < 0) exit(1);
    if(sem_wait(mutex) < 0) exit(1);
    s->buf[s->in] = item;
    s->in = (s->in + 1) % s->size;
    sem_post(mutex);
    sem_post(full);
    printf("Producer PID %d: produced %d\n", getpid(), item);
    busy_delay();
  }

  wait(0);
  printf("Producer/Consumer complete: all %d items transferred in order.\n", ITEMS);
  exit(0);
}
